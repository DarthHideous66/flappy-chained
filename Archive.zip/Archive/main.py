import pygame
from player import Player
import random
import math
from pipe import Pipe

pygame.mixer.init()
pygame.init()
pygame.font.init()

score_font = pygame.font.SysFont('couriernew', 24)
WIDTH, HEIGHT = 1200, 600
MAX_DISTANCE = 200

screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("My Game")

game_over = False
game_started = False
paused = False
score = 0
highscore = 0

background = pygame.image.load("background.GIF").convert()
background = pygame.transform.scale(background, (WIDTH, HEIGHT))

clock = pygame.time.Clock()

player = Player(375, 275, "player1-frames")
player2 = Player(300, 275, "blue-frames")
pipe = Pipe(350, random.randint(200, 550))

wing_sound = pygame.mixer.Sound("flap.mp3")


def reset_game():
    global game_over, paused, game_started, score

    player.reset(375, 275)
    player2.reset(300, 275)
    pipe.reset(350, random.randint(30, 200))

    game_over = False
    paused = False
    game_started = True
    score = 0


running = True

while running:
    screen.blit(background, (0, 0))

    with open("high_score.txt", "r") as f:
        highscore = int(f.read().strip() or 0)

    events = pygame.event.get()

    for event in events:
        if event.type == pygame.QUIT:
            running = False

        if event.type == pygame.KEYDOWN:

            if not game_started and event.key == pygame.K_SPACE:
                game_started = True

            elif game_over:
                if event.key == pygame.K_r:
                    reset_game()
                elif event.key == pygame.K_ESCAPE:
                    running = False

            elif game_started and not game_over and event.key == pygame.K_p:
                paused = not paused

    if player.dead or player2.dead:
        game_over = True

    if game_started and not game_over and not paused:

        if player.play_sound or player2.play_sound:
            wing_sound.play()

        player.handle_inputs(events, pygame.K_a, pygame.K_d, pygame.K_w)
        player.update(pipe)

        player2.handle_inputs(events, pygame.K_LEFT, pygame.K_RIGHT, pygame.K_UP)
        player2.update(pipe)

        score = pipe.update(player, player2)
        pipe.highscore(player.dead, player2.dead)

        distance = math.hypot(player.rect.centerx - player2.rect.centerx,player.rect.centery - player2.rect.centery)

        if distance > MAX_DISTANCE:
            dx = player2.rect.centerx - player.rect.centerx
            dy = player2.rect.centery - player.rect.centery

            dx /= distance
            dy /= distance

            stretch = distance - MAX_DISTANCE
            force = stretch * 0.05

            player.velocity_x += dx * force
            player.velocity_y += dy * force

            player2.velocity_x -= dx * force
            player2.velocity_y -= dy * force

    if game_started:
        player.draw(screen)
        player2.draw(screen)

        pygame.draw.line(screen, (80, 80, 80),player.rect.center, player2.rect.center, 5)

        pipe.draw(screen)

        scoreboard = score_font.render(f"Score: {score}   High score: {highscore}",True, (255, 255, 255))
        screen.blit(scoreboard, (20, 20))

    if not game_started:
        start_text = score_font.render("Press SPACE to Start", True, (255, 255, 255))
        screen.blit(start_text, (450, 250))

    if paused and not game_over:
        pause_text = score_font.render("PAUSED - Press P to Unpause", True, (255, 255, 0))
        screen.blit(pause_text, (390, 250))

        pause_score = score_font.render(f"Score: {score}   High score: {highscore}",True, (255, 255, 255))
        screen.blit(pause_score, (420, 300))

    if game_over:
        game_over_text = score_font.render("Game Over! Press R to Restart or ESC to Quit",True, (255, 255, 255))
        screen.blit(game_over_text, (250, 250))

        final_score = score_font.render(f"Score: {score}   High score: {highscore}",True, (255, 255, 255))
        screen.blit(final_score, (420, 300))

    pygame.display.flip()
    clock.tick(60)

pygame.quit()
